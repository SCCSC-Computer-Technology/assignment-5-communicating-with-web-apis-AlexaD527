﻿using AlexaDavisWebApp.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace AlexaDavisWebApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> logger;
        private readonly IHttpClientFactory httpClientFactory;

        // Constructor initialization with dependency injection
        public HomeController(ILogger<HomeController> log, IHttpClientFactory clientFactory)
        {
            logger = log;
            httpClientFactory = clientFactory;
        }

        // Default landing page
        public IActionResult Index()
        {
            return View();
        }

        // Display the Privacy Policy page
        public IActionResult Privacy()
        {
            return View();
        }

        // Fetches all student profiles from the API and displays them
        public async Task<IActionResult> Students()
        {
            string apiEndpoint = "api/StudentProfiles";
            HttpClient client = httpClientFactory.CreateClient("StudentProfileWebApi");
            HttpRequestMessage request = new(HttpMethod.Get, apiEndpoint);
            HttpResponseMessage response = await client.SendAsync(request);
            IEnumerable<StudentProfile>? profiles = await response.Content.ReadFromJsonAsync<IEnumerable<StudentProfile>>();
            return View(profiles);
        }

        // Error handling page
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            var errorModel = new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier };
            return View(errorModel);
        }
    }
}
